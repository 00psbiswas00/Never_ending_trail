# Never Ending Trail Club · Design System

Logo, colour, type and web components for NETC. One standard for every trip we tell, whoever is holding the file.

## What's here

| Folder | What |
| --- | --- |
| `brand-book/` | The Brand Book PDF (v1.0, September 2026) and `guidelines.md`, the same rules as text |
| `tokens/` | `tokens.json` (source of truth) and `tokens.css` (CSS custom properties, light and indigo themes) |
| `components/` | `bundle.js` (React components on `window.NETC`), `bundle.css`, `index.d.ts`, a README and preview per component |
| `logos/` | Every logo file: SVG for screen, PNG ready to post, PDF for print. See `logos/README.txt` |

## Use it on a page

```html
<link rel="stylesheet" href="tokens/tokens.css">
<link rel="stylesheet" href="components/bundle.css">
<script src="https://cdn.jsdelivr.net/npm/react@18/umd/react.production.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/react-dom@18/umd/react-dom.production.min.js"></script>
<script src="components/bundle.js"></script>
```

Wrap any dark section in `data-theme="indigo"` and the colours swap. Components: `Button`, `TextLink`, `TripTag`, `Frame`, `TripCard`.

## Palette

| Name | Hex | Job |
| --- | --- | --- |
| Indigo | `#23325E` | The frame, headings, home background |
| Red | `#C9372C` | The route, links, one accent. On indigo: `#E0503F` |
| Turmeric | `#E3A21A` | The sun, trip tags. On indigo: `#EDB22A` |
| Cream | `#F1E9D8` | Paper, and the frame on indigo |
| Ink | `#16130F` | Body text, one-colour stamps |
| Paper | `#FBF8F1` | Page background |

## Type

Archivo Expanded 800 (display), Archivo 400/600 (text), IBM Plex Mono 500/600 (labels, trip tags), Anek Bangla 500/700 (Bangla). All on Google Fonts.

Full rules: `brand-book/guidelines.md`.
