A group of Bengali friends who travel anywhere, by any means: bike, train, road, boat, plane, mountains. Every trip becomes a story on our social pages, YouTube, blog and vlogs. **Every trip is a frame.** Pattachitra, Bengal's scroll painting, is the storytelling metaphor: each trip is one panel of an endless scroll.

Every value here is decided. If a rule is missing, decide it, add it to this system, and only then post.

## What the brand must say

- **A travel club.** Not an art group, not a company.
- **Young and open.** Modern, and welcoming to every culture.
- **Proudly Bengali.** Bangla sits beside English as an equal, never as decoration.

## Voice

Friends telling the story.

- **Told as we.** First person plural. "We went, we got lost, we found the tea stall."
- **Place first.** Lead with the place, the moment and the people. Facts and tips after.
- **Two languages.** Bangla and English side by side, one voice. Never a stiff word-for-word translation.
- **Never:** clickbait, fake hype, influencer cliches, em dashes, or a trip we didn't take.
- **Fixed patterns.** Headlines in capitals, captions in sentence case. Every post about a trip opens with its tag: `TRIP 07 · [PLACE]`.
- No emoji in brand copy.

Real copy to match: "We missed the last bus, so we walked. The tea stall was worth it."

## Logo

The mark is **frame, sun, route**. The frame is one trip, one panel of a Patua scroll. The sun is the early start and the next place. The route and its two dots are however we got there; they walk out of the frame and keep going: never ending.

Built on a 200 unit grid: frame stroke 16 with sharp corners, exit gap 56 tall on the right side, sun Ø36 centred at 134,64, route stroke 16 with round ends, dots Ø16 centred at 164 and 186. Redraws that don't follow these numbers are wrong. Always use the master files in the **Lockups**, **Marks** and **Patches** asset groups; never redraw.

### Which logo, where

| Use | File | Where |
| --- | --- | --- |
| Primary | `netc-primary-horizontal-*` | The default. Website header, documents, merch. Not sure? Use this. |
| Secondary | `netc-secondary-stacked-*` | Square spaces, posters, T-shirts. |
| Alternate, bilingual | `netc-alternate-bilingual-*` | English with the Bangla name. Bengali posts, events. |
| Alternate, Bangla first | `netc-alternate-bangla-first-*` | Anywhere Bangla leads. |
| Brand mark | `netc-mark-*` | The mark alone when the name is nearby: patch, stamp, end cards. |
| Social | `netc-social-avatar-1080` | Every profile picture (Instagram, Facebook, LinkedIn). Survives every circle crop. |
| Favicon | `favicon.svg` | Browser tabs, bookmarks, anything under 24px. |

### One mark, three sizes

Pick by the size it will show at, not the size of the file.

- **Primary mark:** 48px and up, 12mm and up.
- **Compact** (`netc-compact-*`): 24 to 47px, 6 to 12mm. Heavier lines, one dot. Every social avatar, small print, badges under 4cm.
- **Micro** (`favicon.svg`): under 24px. Always on its indigo tile.

### Colourways

- `colour`: indigo, red, turmeric on `cream`, `paper` or white. Pages and posts.
- `reverse`: full colour for `indigo` grounds. The home version: avatars, patch, thumbnails. Transparent; it looks empty on white.
- `indigo` / `ink`: one colour. Stamps, emboss, laser, partner lockups. `ink` is for rubber stamps (mark only).
- `white`: one colour over photos and video. The watermark.

### Clear space and minimum sizes

Clear space **x = two sun widths** (72 units), on all four sides, scaled with the logo. No text, rules, photo edges or page margins inside it. More is fine; crowding is the most common misuse.

| Version | Screen | Print |
| --- | --- | --- |
| Mark alone | 24px | 8mm |
| Horizontal lockup | 120px wide | 30mm |
| Stacked lockup | 80px wide | 20mm |
| Bilingual lockup | 160px wide | 40mm |

Below 48px switch to Compact; below 24px switch to Micro. SVG for screen, PDF for print.

### Don't

Stretch or squash it. Change the colours. Round the corners. Close the frame or drop the dots. Put it on `red` or `turmeric`. Add shadows or effects. One exception: the rubber stamp may sit at a slight tilt.

## Colour

Five colours, five jobs. No colours outside this palette, no gradients, no second red or yellow.

- `cream` is the **ground**: pages, posts, cards. `paper` is its lighter step for page backgrounds.
- `indigo` is the **frame**: frames, headings, dark grounds.
- `ink` is **text**: body copy, one-colour stamps.
- `red` is the **route**: lines, links, one accent.
- `turmeric` is the **sun**: sun, trip tags, highlights.

Proportions are a guide, not a ruler. Light layout (pages, posts, blog): cream 55, indigo 25, ink 10, red 6, turmeric 4. Dark layout (avatars, thumbnails, patch): indigo 60, cream 20, red 10, turmeric 10. `red` and `turmeric` never fill behind body copy.

On indigo, the accents step up: use `red-on-indigo` for the route and `turmeric-on-indigo` for the sun and tags. Build with the semantic tokens (`ground`, `surface`, `text`, `heading`, `frame`, `route`, `sun`, `link`) and the two themes swap these for you: `light` for pages, `indigo` for dark layouts.

### Six approved pairings. No others.

| Pair | Contrast |
| --- | --- |
| `indigo` on `cream` | 10.3:1 |
| `cream` on `indigo` | 10.3:1 |
| `turmeric-on-indigo` on `indigo` | 6.5:1 |
| `ink` on `turmeric` | 8.3:1 |
| `indigo` on `turmeric` | 5.6:1 |
| `red` on `paper` | 4.9:1 |

`ink` on `paper` and `cream` (17.5:1, 15.3:1) is the body copy default. `turmeric` is never text on cream or white (2.1:1 fails); it stays a shape there, like the sun.

## Type

Three families, never more than three weights on one page. All are on Google Fonts.

- **Archivo Expanded** (`display`, width axis 125): headlines, the wordmark, big numbers. ExtraBold 800, capitals, line height 100 to 105%. Never italic, never condensed. Fallback Arial Black.
- **Archivo** (`sans`): captions, blog text, descriptions, buttons. Regular 400 and SemiBold 600, line height 140 to 150%. Fallback Arial.
- **IBM Plex Mono** (`mono`): trip numbers, places, dates, eyebrows. Medium 500 and SemiBold 600, capitals, 3px tracking. Fallback Courier New.
- **Anek Bangla** (`bangla`): the Bangla name, captions and titles. Bold 700 for the name and headlines, Medium 500 for captions. The same name in both scripts, never a translation. In running text, Bangla sits at the same size as the English beside it.

### Scale

Use `display`, `h1`, `h2`, `h3`, `body`, `label` on desktop and their `-m` versions under 768px wide. Body never below 16px, lines up to 75 characters. `display` and `h1` need `font-stretch: 125%` and capitals; `bundle.css` sets both on those classes.

## Layout and components

**Sharp, like the frame.** Every corner is `radius-none`; `radius-round` is only for circles the brand already has (sun, dots, avatar crop).

- **Spacing:** 8px grid. Sections `space-12` (96px) apart on desktop, `space-7` (56px) on mobile.
- **Buttons:** primary is `button-primary-bg` (red on light, cream on indigo). One per screen, sharp corners. Secondary is an outline in `frame`.
- **Links:** `link`, always underlined. Never turmeric.
- **Cards and images:** framed in `frame`, `frame-sm` to `frame-lg` by size. No shadows, no rounded corners.
- **Focus:** `focus-width` outline at `focus-offset`, in `focus` (indigo on light, turmeric on indigo).
- **Motion:** 150 to 200ms, colour and border only. The route line may draw in once, on scroll.

### The trip tag

Every trip has a number, counted from one. It never changes once used. Two digits until trip 99. IBM Plex Mono SemiBold, capitals: `TRIP 07 · [PLACE]`. Turmeric fill with indigo text on light; turmeric text on indigo. It opens every post, reel, video and blog story, so every piece joins the scroll. In Bangla: `ট্রিপ ০৭ · [জায়গা]`.

## Applications

- **Social:** compact mark on indigo as the avatar everywhere. Every photo sits in the square indigo frame, so the grid reads like panels of a scroll. Always the group, never solo portraits. Captions in Bangla and English, trip tag first.
- **YouTube thumbnail:** indigo frame as the border, turmeric sun where it sits in the logo, red route leaving the frame. White watermark in the corner.
- **Blog:** horizontal lockup in the header. Every story opens with its trip tag, headline and hero photo in the frame.
- **Website:** header with the horizontal lockup left, two or three links, one red button. Hero on indigo ground with the latest trip tag, one headline, one framed photo. Trip cards: framed photo, turmeric tag, title, newest first. Footer on indigo with the Bangla name, links and socials.
- **Patch:** 8cm square, indigo edge, sun and route with the name below. Thread in indigo, cream, red, turmeric.
- **Stamp:** one ink, one stamp per trip in the club journal. Lines at least 2pt.
- **Watermark:** white mark at `watermark` opacity (80%), bottom right, 150px on a 1080p frame.
- **Favicon:** Micro on its tile. Export 16, 32 and 180px.

## Iconography

The brand defines no icon set and uses no emoji. The only symbols are the mark and its parts: the frame, the sun disc and the route dots. If an interface needs icons, decide the set and add it here first.

## Imagery

Real trip photos only, of the group. Photos always sit inside the frame. Never a trip we didn't take.
