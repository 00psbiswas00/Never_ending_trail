# Button

The one call to action per screen, with sharp corners. The consumer provides the label (verb first, sentence case: "Join a trip") and either `onClick` or `href`.

- `primary`: `button-primary-bg` with `button-primary-text`. Red with a paper label on light, cream with an indigo label on indigo. Only one per screen.
- `secondary`: an outline in `frame` with `heading` text ("See all trips"). Use as many as needed.
- Focus: 3px `focus` outline at 3px offset.
- Don't round it, add a shadow, or make it turmeric.
