# Frame

A photo in the frame: one panel of the scroll. The consumer provides `src` and `alt` (real trip photos of the group, never solo portraits) and picks `weight` by size.

- Border in `frame`: indigo on light, cream on indigo. `frame-sm` 2px for thumbnails, `frame-md` 4px for cards and grid tiles, `frame-lg` 8px for hero photos.
- `sun` adds the turmeric disc top right, where it sits in the logo. Heroes and thumbnails only.
- `ratio="1 / 1"` for the social grid.
- No shadows, no rounded corners, no filters.
