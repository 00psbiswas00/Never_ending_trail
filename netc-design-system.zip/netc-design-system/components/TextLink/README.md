# TextLink

An inline text link, always underlined. The consumer provides `href` and the link text.

- Uses `link`: red on light (4.9:1 on paper), cream on indigo.
- Never turmeric: it fails contrast on light grounds.
- Keep link text specific: "Read the story", not "Click here".
