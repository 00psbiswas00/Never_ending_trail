# TripCard

A website trip card: framed photo, trip tag, title. The consumer provides `number`, `title`, `src`, `alt` and usually `href`; lay cards in a grid, newest trip first, `space-3` apart.

- Photo in a `frame-md` frame, tag below it, title in Archivo SemiBold in `heading`.
- One card, one trip. No excerpts, dates or buttons inside the card.
