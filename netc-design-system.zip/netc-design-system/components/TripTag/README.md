# TripTag

The trip number that opens every story: `TRIP 07 · [PLACE]`. The consumer provides `number` (counted from one, never changed once used) and optionally `place` and `lang`.

- On light: `tag-bg` turmeric fill with `tag-text` indigo. On indigo: no fill, turmeric text. Always turmeric.
- IBM Plex Mono SemiBold, capitals, 3px tracking. Two digits until trip 99.
- `lang="bn"` sets Anek Bangla with Bengali digits: `ট্রিপ ০৭ · [জায়গা]`.
- Put it first on every post, reel, video and blog story. `size="lg"` on heroes and thumbnails.
