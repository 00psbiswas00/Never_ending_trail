/* @ds-bundle: {"format":4,"namespace":"NETC","components":[{"name":"Button"},{"name":"TextLink"},{"name":"TripTag"},{"name":"Frame"},{"name":"TripCard"}]} */
(function () {
  var h = function () { return window.React.createElement.apply(null, arguments); };
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }
  var BN = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
  function pad(n) { var s = String(n); return s.length < 2 ? '0' + s : s; }
  function bnDigits(s) { return String(s).replace(/[0-9]/g, function (d) { return BN[+d]; }); }

  function Button(p) {
    var variant = p.variant || 'primary';
    var cls = cx('netc-btn', 'netc-btn--' + variant, p.className);
    if (p.href) return h('a', { href: p.href, className: cls, onClick: p.onClick }, p.children);
    return h('button', { type: p.type || 'button', className: cls, onClick: p.onClick, disabled: p.disabled }, p.children);
  }

  function TextLink(p) {
    return h('a', { href: p.href || '#', className: cx('netc-link', p.className) }, p.children);
  }

  function tripTagText(number, place, lang) {
    var n = pad(number);
    if (lang === 'bn') return 'ট্রিপ ' + bnDigits(n) + (place ? ' · ' + place : '');
    return 'TRIP ' + n + (place ? ' · ' + place : '');
  }
  function TripTag(p) {
    var lang = p.lang || 'en';
    return h('span', { className: cx('netc-tag', p.size === 'lg' && 'netc-tag--lg', lang === 'bn' && 'netc-tag--bn', p.className), lang: lang === 'bn' ? 'bn' : undefined },
      tripTagText(p.number, p.place, lang));
  }

  function Frame(p) {
    var weight = p.weight || 'md';
    return h('figure', { className: cx('netc-frame', weight !== 'md' && 'netc-frame--' + weight, p.className), style: { aspectRatio: p.ratio || '4 / 3' } },
      p.src ? h('img', { src: p.src, alt: p.alt || '' }) : null,
      p.sun ? h('span', { className: 'netc-frame__sun', 'aria-hidden': 'true' }) : null);
  }

  function TripCard(p) {
    var body = [
      h(Frame, { key: 'f', src: p.src, alt: p.alt, weight: 'md', ratio: p.ratio || '3 / 2' }),
      h(TripTag, { key: 't', number: p.number, lang: p.lang, className: 'netc-card__tag' }),
      h('h3', { key: 'h', className: 'netc-card__title' }, p.title)
    ];
    return h('article', { className: cx('netc-card', p.className) }, p.href ? h('a', { href: p.href }, body) : body);
  }

  window.NETC = { Button: Button, TextLink: TextLink, TripTag: TripTag, Frame: Frame, TripCard: TripCard, tripTagText: tripTagText };
})();
