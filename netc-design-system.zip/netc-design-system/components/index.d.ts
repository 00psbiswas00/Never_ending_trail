import * as React from 'react';

/** One primary per screen. Sharp corners. Theme decides colours: red on light, cream on indigo. */
export interface ButtonProps {
  /** 'primary' = the one call to action; 'secondary' = outline in `frame`. Default 'primary'. */
  variant?: 'primary' | 'secondary';
  /** Renders an <a> when set. */
  href?: string;
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  className?: string;
  children: React.ReactNode;
}
export declare function Button(props: ButtonProps): React.ReactElement;

/** Underlined text link in `link`: red on light, cream on indigo. Never turmeric. */
export interface TextLinkProps { href?: string; className?: string; children: React.ReactNode; }
export declare function TextLink(props: TextLinkProps): React.ReactElement;

/** TRIP 07 · [PLACE]. Opens every story. Number is padded to two digits. */
export interface TripTagProps {
  /** The trip number, counted from one. Never changes once used. */
  number: number;
  /** Place name, in the tag's language. Optional. */
  place?: string;
  /** 'en' (IBM Plex Mono) or 'bn' (Anek Bangla, Bengali digits). Default 'en'. */
  lang?: 'en' | 'bn';
  /** 'md' 14px (default) or 'lg' 20px for heroes and thumbnails. */
  size?: 'md' | 'lg';
  className?: string;
}
export declare function TripTag(props: TripTagProps): React.ReactElement;

/** A photo in the indigo frame: one panel of the scroll. No shadows, no rounding. */
export interface FrameProps {
  src?: string;
  alt?: string;
  /** Frame weight by size: 'sm' 2px (thumbnails), 'md' 4px (cards, default), 'lg' 8px (hero). */
  weight?: 'sm' | 'md' | 'lg';
  /** CSS aspect-ratio. Default '4 / 3'. Use '1 / 1' for social grid tiles. */
  ratio?: string;
  /** Adds the turmeric sun disc top right, as in the logo. Hero and thumbnails only. */
  sun?: boolean;
  className?: string;
}
export declare function Frame(props: FrameProps): React.ReactElement;

/** Website trip card: framed photo, turmeric trip tag, title. Newest trip first. */
export interface TripCardProps {
  number: number;
  title: string;
  src?: string;
  alt?: string;
  href?: string;
  lang?: 'en' | 'bn';
  ratio?: string;
  className?: string;
}
export declare function TripCard(props: TripCardProps): React.ReactElement;

/** Returns the tag text, e.g. tripTagText(7, 'DARJEELING') => 'TRIP 07 · DARJEELING'. */
export declare function tripTagText(number: number, place?: string, lang?: 'en' | 'bn'): string;
